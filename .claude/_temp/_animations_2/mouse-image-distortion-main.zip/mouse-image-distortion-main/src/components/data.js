export const projects = [
    {
      title: "Richard Gaston",
      src: "/images/5.jpg"
    },
    {
      title: "KangHee Kim",
      src: "/images/6.jpg"
    },
    {
      title: "Inka and Niclas",
      src: "/images/7.jpg"
    },
    {
      title: "Arch McLeish",
      src: "/images/2.jpg"
    },
    {
      title: "Nadir Bucan",
      src: "/images/1.jpg"
    },
    {
      title: "Chandler Bondurant",
      src: "/images/3.jpg"
    },
    {
      title: "Arianna Lago",
      src: "/images/4.jpg"
    }
]