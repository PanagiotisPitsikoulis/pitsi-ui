import floating1 from '../public/images/floating_1.jpg';
import floating2 from '../public/images/floating_2.jpg';
import floating3 from '../public/images/floating_3.jpg';
import floating4 from '../public/images/floating_4.jpg';
import floating5 from '../public/images/floating_5.jpg';
import floating6 from '../public/images/floating_6.jpg';
import floating7 from '../public/images/floating_7.jpg';
import floating8 from '../public/images/floating_8.jpg';

export { 
    floating1, 
    floating2, 
    floating3, 
    floating4, 
    floating5, 
    floating6, 
    floating7, 
    floating8
}